/* MÅLERIGG — bevisst ødelagt bundle (rig-broken-1).
   Erstatter app.js i riggbundelen. Readiness-punktet nås aldri — ingenting
   her avvæpner pluginen, så rollback-timeren utløser etter readyTimeout.
   docs/mobilapp-plan.md, «Den ødelagte bundelen kan ikke være en
   produksjonsrelease». */
'use strict';
document.title = 'RIGG — ødelagt bundle';
document.addEventListener('DOMContentLoaded', function () {
  var p = document.createElement('p');
  p.textContent = 'MÅLERIGG: bevisst ødelagt bundle rig-broken-1 — skal rulles tilbake av readyTimeout.';
  document.body.prepend(p);
});
throw new Error('rigg: bevisst ødelagt bundle rig-broken-1');
